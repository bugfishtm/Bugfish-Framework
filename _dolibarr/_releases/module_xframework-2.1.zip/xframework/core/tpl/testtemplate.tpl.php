<?php
	/*
		__________              _____.__       .__     
		\______   \__ __  _____/ ____\__| _____|  |__  
		 |    |  _/  |  \/ ___\   __\|  |/  ___/  |  \ 
		 |    |   \  |  / /_/  >  |  |  |\___ \|   Y  \
		 |______  /____/\___  /|__|  |__/____  >___|  /
				\/     /_____/               \/     \/  Doliabrr Template File Example */

// No Hardlinkin on a Template!
if (empty($conf) || ! is_object($conf)) { print "Error, no Hardlink!"; exit; }

// Write your template code here!
echo "No code has been added yet!";
