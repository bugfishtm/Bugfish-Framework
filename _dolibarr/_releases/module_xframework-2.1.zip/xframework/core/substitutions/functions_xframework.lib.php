<?php
	/*
		__________              _____.__       .__     
		\______   \__ __  _____/ ____\__| _____|  |__  
		 |    |  _/  |  \/ ___\   __\|  |/  ___/  |  \ 
		 |    |   \  |  / /_/  >  |  |  |\___ \|   Y  \
		 |______  /____/\___  /|__|  |__/____  >___|  /
				\/     /_____/               \/     \/  Doliabrr Substitutions File Example */
				
	// Here you can add Substitution Operations!
	function xframework_completesubstitutionarray(&$substitutionarray, $langs, $object) {
		global $conf,$db;
	}
?>
