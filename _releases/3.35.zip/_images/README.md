🖼️ **Repository Images**

This folder houses images utilized in the repository's readme file.

To incorporate these images in the repository's readme file, utilize the following Markdown syntax:

```markdown
![Alt Text](image_path)
```

Replace Alt Text with a descriptive text for the image and image_path with the relative path to the image file within this folder.

🐟 Bugfish <3