//Ref: https://highlightjs.readthedocs.io/en/latest/index.html
//Initialise highlight js on <pre></code> blocks
hljs.initHighlighting();