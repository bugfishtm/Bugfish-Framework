# Download

This page provides access to view the GitHub repository and download the latest file from the repository.

## View the GitHub Repository

You can explore the code and files in the GitHub repository by clicking the link below:

[View GitHub Repository](https://github.com/bugfishtm/bugfish-framework){.md-button}

## Download the Latest File

To download the latest file from the repository directory, click the link below:

[Download Latest Release](https://github.com/bugfishtm/bugfish-framework/archive/refs/heads/main.zip){.md-button}