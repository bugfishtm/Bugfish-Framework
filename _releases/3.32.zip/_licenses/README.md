📜 **Licenses**

This folder contains licenses for third-party libraries utilized in the project. Additional information about the licenses of third-party applications and corresponding source code can be found within their respective folders inside the project's source code itself or in the project's documentation.

Happy coding and have a great one!  
🐟 Bugfish <3