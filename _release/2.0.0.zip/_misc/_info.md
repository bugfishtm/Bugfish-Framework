In this folder are things for different purposes.  
Check the info.md in the related folder to see what this folder is about!  
MIT License may not apply here. But see inside the folders for yourself.  
This files are not part of the framework, they are more a help for development.