Deploy fast a testing environment (like xampp) with docker.  
See docker files for more information! Put your website files in _source directory!